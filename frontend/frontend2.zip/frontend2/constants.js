export const constants = {
    // BASE_URL: 'http://testapi3.starwarsstore.store',
    BASE_URL: 'http://localhost:3000'
}